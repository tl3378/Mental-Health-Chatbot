# Mental Health Support Chatbot

A supportive chatbot designed to provide a safe space for mental health conversations. Built with Streamlit and powered by OpenAI's GPT-3.5.

## Features

- 🎨 Beautiful, responsive UI with message bubbles
- 🔒 Safe and supportive conversation environment
- ⚡ Real-time message processing
- 🛡️ Content moderation for safety
- 🆘 Emergency help resources
- 💬 Natural conversation flow

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/Mental-Health-Chatbot.git
cd Mental-Health-Chatbot
```

2. Create and activate a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows, use: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up your OpenAI API key:
   - Create a file named `model.env` in the `conversationchain` directory
   - Add your OpenAI API key:
     ```
     OPENAI_API_KEY='your-api-key-here'
     ```

## Usage

1. Start the application:
```bash
streamlit run app.py
```

2. Open your browser and navigate to:
   - Local: http://localhost:8501
   - Network: http://your-ip:8501

## Project Structure

```
Mental-Health-Chatbot/
├── app.py                  # Main Streamlit application
├── requirements.txt        # Project dependencies
├── README.md              # Project documentation
├── conversationchain/     # Core chatbot functionality
│   ├── __init__.py
│   ├── app_setup.py      # Conversation chain setup
│   ├── chatbot_fn.py     # Main chatbot function
│   ├── config.py         # Configuration and API setup
│   ├── moderation.py     # Content moderation
│   └── model.env         # Environment variables
└── logs/                 # Application logs
```

## Features in Detail

### UI Components
- Gradient welcome banner
- Message bubbles with animations
- Responsive input area
- Emergency help button
- Important disclaimers

### Safety Features
- Content moderation
- Crisis response system
- Emergency resource links
- Professional help recommendations

### Technical Features
- Real-time message processing
- Enter key support
- Mobile-friendly design
- Error handling and logging
- Session state management

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Disclaimer

This chatbot is not a substitute for professional mental health care. If you're in crisis, please seek immediate help from a mental health professional or emergency services.
